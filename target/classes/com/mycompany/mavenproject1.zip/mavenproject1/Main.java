/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

import java.util.ArrayList;
import java.util.Date;
import static spark.Spark.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import spark.ModelAndView;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import spark.Spark;
//import spark.template.handlebars.HandlebarsTemplateEngine;

public class Main {

    private static final String SESSION_NAME = "username";
    private static SessionFactory factory;

    public static void main(String[] args) {

        Spark.exception(Exception.class, (exception, request, response) -> {
            exception.printStackTrace();
        });

        try {
            factory = new Configuration().configure("/hibernate.cfg.xml").buildSessionFactory();
        } catch (Throwable ex) {
            System.err.println("Failed to create sessionFactory object." + ex);
            throw new ExceptionInInitializerError(ex);
        }

        get("/agregar", (req, res) -> {
            String insertID="";
            Session session = factory.openSession();
            Transaction tx = null;
           

            try {
                tx = session.beginTransaction();
                Cliente cliente = new Cliente("Fulano", "8098888", "Santiago", 1);
                insertID =   session.save(cliente).toString();
                tx.commit();
                
            } catch (HibernateException e) {
                if (tx != null) {
                    tx.rollback();
                }
                e.printStackTrace();
            } finally {
                session.close();
            }
            return "Insertado:"+insertID;
        });
        get("/", (req, res) -> {
            String name = req.session().attribute(SESSION_NAME);

            if (name == null) {
                String html = "<html><body>";
                if (req.queryParams("err") != null) {
                    html += "Error login";
                }
                html += "<form action=\"/login\" "
                        + "method=\"POST\"> Usuario:<input type=\"text\" name=\"user\"/>"
                        + "<br />Password<input type=\"passowrd\" name=\"pass\" /><input type=\"submit\" value=\"go\"/></form></body></html>";
                return html;
            } else {
                return String.format("<html><body>Hello, %s!</body></html>", name);
            }
        });

        post("/login", (request, response) -> {
            String user = request.queryParams("user");
            String pass = request.queryParams("pass");
            if (user.toLowerCase().equals("admin") && pass.equals("123456")) {
                request.session().attribute(SESSION_NAME, user);
                response.redirect("/");
            } else {
                response.redirect("/?err=1");
            }
            return null;
        });

        get("/clear", (request, response) -> {
            request.session().removeAttribute(SESSION_NAME);
            response.redirect("/");
            return null;
        });
    }
}
